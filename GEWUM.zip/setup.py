"""
GEWUM Setup Script
For backward compatibility with older pip versions
"""

from setuptools import setup, find_packages
import os

# Read the README for long description
readme_path = os.path.join(os.path.dirname(__file__), "GEWUM_Manual.md")
if os.path.exists(readme_path):
    with open(readme_path, encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "GEWUM: General Exploration Workflow for the Utopia of Materials"

# Find all subpackages and add gewum prefix
subpackages = find_packages(where=".")
packages = ["gewum"] + [f"gewum.{pkg}" for pkg in subpackages]

setup(
    name="gewum",
    version="1.0.0",
    author="Jiexi Song",
    author_email="songjx@szlab.ac.cn",
    description="GEWUM: General Exploration Workflow for the Utopia of Materials",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/gewum",
    packages=packages,
    package_dir={"gewum": "."},
    include_package_data=True,
    package_data={
        "gewum": [
            "src/**/*.py",
            "src/**/*.sh",
            "src/**/*.in*",
            "slurm_config.yaml",
            "replacements.yaml",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Physics",
        "Topic :: Scientific/Engineering :: Chemistry",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "pandas>=1.3.0",
        "matplotlib>=3.4.0",
        "ase>=3.22.0",
        "pymatgen>=2022.0.0",
        "pyyaml>=5.4.0",
        "scipy>=1.7.0",
        "pyxtal>=0.6.0",
        "spglib>=2.0.0",
        "phonopy>=2.20.0",
        "phono3py>=2.0.0",
        "mp-api>=0.30.0",
        "scikit-learn>=1.0.0",
        "hdbscan>=0.8.0",
        "dscribe>=1.2.0",
        "tqdm",
    ],
    extras_require={
        "ml": ["mattersim"],
        "dev": ["pytest>=6.0", "black", "flake8"],
    },
    entry_points={
        "console_scripts": [
            "gewum=gewum.main:main",
        ],
    },
)
