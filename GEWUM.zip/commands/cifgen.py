import sys
import os
import importlib.util
from ..config import CIFGEN_MODULE


def _load_cifgen_module(module_name):
    """Load a cifgen sub-module using importlib from CIFGEN_MODULE directory."""
    module_file = os.path.join(CIFGEN_MODULE, f"{module_name}.py")
    if not os.path.exists(module_file):
        raise ImportError(f"Module file not found: {module_file}")
    full_name = f"cifgen_input.{module_name}"
    spec = importlib.util.spec_from_file_location(full_name, module_file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def setup_args(parser):
    parser.add_argument("--mode", 
                        choices=["all", "oxidation", "substitute", "mutate", "dp"], 
                        required=True,
                        help="Execution mode:\n"
                             "  all: Generate all compositions\n"
                             "  oxidation: Generate compositions with common oxidation states\n"
                             "  substitute: Generate structures with element substitutions\n"
                             "  mutate: Generate perturbed structures from a template CIF\n"
                             "  dp: Generate doped structures with random atom replacements")

def execute(args):
    print(f"GEWUM CIF Generation - Mode: {args.mode}")
    
    if not os.path.exists(CIFGEN_MODULE):
        print(f"[ERROR] CIFGEN module directory not found: {CIFGEN_MODULE}")
        sys.exit(1)
    
    try:
        print("Starting CIF generation workflow...")
        
        if args.mode == "all":
            chemi = _load_cifgen_module("chemi")
            conv_all = _load_cifgen_module("conv_all_cifgen")
            chemi.main()
            conv_all.main()
        elif args.mode == "oxidation":
            chemi = _load_cifgen_module("chemi")
            oxidation = _load_cifgen_module("oxidation")
            conv_oxidation = _load_cifgen_module("conv_oxidation_cifgen")
            chemi.main()
            oxidation.main()
            conv_oxidation.main()
        elif args.mode == "substitute":
            substitute = _load_cifgen_module("substitute")
            substitute.main()
        elif args.mode == "mutate":
            mutate = _load_cifgen_module("mutate")
            mutate.main()
        elif args.mode == "dp":
            doping = _load_cifgen_module("doping")
            doping.main()
        else:
            print(f"[ERROR] Unknown mode: {args.mode}")
            sys.exit(1)
            
    except ImportError as e:
        print(f"[ERROR] Failed to import cifgen modules: {e}")
        print(f"[DEBUG] Python path: {sys.path}")
        print(f"[DEBUG] Files in cifgen_input: {os.listdir(CIFGEN_MODULE) if os.path.exists(CIFGEN_MODULE) else 'Directory not found'}")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] CIF generation failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
