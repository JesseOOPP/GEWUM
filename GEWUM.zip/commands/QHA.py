import os
import shutil
import subprocess
import sys
from ..config import QHA_REPOSITORY
from .template_utils import get_config_info, copy_with_template

GEWUM_FILE_MAP = {
    "pre": [],
    "cal": ["cal_qha.sh"],
}

DIRECT_EXEC_MODULES = {
    "pre": "gewum.src.QHAworkflows.qha_dir",
}

MODE_DESCRIPTIONS = """
  pre: Create a directory for each CIF file (-r)
  cal: QHA calculation scripts
"""

def setup_args(parser):
    """Configure command arguments"""
    parser.add_argument("--mode", 
                        required=True,
                        choices=list(GEWUM_FILE_MAP.keys()),
                        help=f"GEWUM QHA mode:\n{MODE_DESCRIPTIONS}"
    )
    parser.add_argument("--dest", 
                        default=".",
                        help="Target directory (default: current directory)")
    parser.add_argument(
        "-r",
        action="store_true",
        dest="run",
        help="Directly execute (pre)"
    )

def execute(args):
    """Execute the QHA workflow command"""
    if hasattr(args, 'run') and args.run:
        if args.mode in DIRECT_EXEC_MODULES:
            module_name = DIRECT_EXEC_MODULES[args.mode]
            print(f"Executing {args.mode} in current directory...")
            try:
                result = subprocess.run([sys.executable, "-m", module_name], check=True)
                return
            except subprocess.CalledProcessError as e:
                print(f"Error executing {args.mode}: {e}")
                sys.exit(1)
        else:
            print(f"Warning: Mode '{args.mode}' does not support direct execution (-r).")
            print(f"Supported modes: {', '.join(DIRECT_EXEC_MODULES.keys())}")
            print("Falling back to copy mode...")
    
    copied = []
    missing = []
    
    if args.dest != '.' and not os.path.isdir(args.dest):
        os.makedirs(args.dest, exist_ok=True)
    
    config_path, config = get_config_info(args.dest)
    
    print(f" Preparing GEWUM {args.mode} scripts...")
    print(f" Source repository: {QHA_REPOSITORY}")
    
    if config_path:
        print(f" Using SLURM config: {config_path}")
    else:
        print(" No slurm_config.yaml found, using default values in scripts")
    
    if not os.path.exists(QHA_REPOSITORY):
        print(f"[ERROR] Source repository not found: {QHA_REPOSITORY}")
        return
    
    #print(f" Available files in repository: {os.listdir(QHA_REPOSITORY)}")
    
    for filename in GEWUM_FILE_MAP[args.mode]:
        src_path = os.path.join(QHA_REPOSITORY, filename)
        dst_path = os.path.join(args.dest, filename)
        
        if not os.path.exists(src_path):
            missing.append(filename)
            continue
        
        if filename.endswith('.sh') and config is not None:
            copy_with_template(src_path, dst_path, config)
        else:
            shutil.copy2(src_path, dst_path)
        copied.append(filename)
    
    print("\n" + "=" * 60)
    print(f" GEWUM {args.mode} scripts copy results")
    print("-" * 60)
    
    if copied:
        print("Copied files:")
        for f in copied:
            print(f"  - {f}")
    
    if missing:
        print("\n Missing files in GEWUM repository:")
        for f in missing:
            print(f"  - {f}")
    
    print(f"\n Target location: {os.path.abspath(args.dest)}")
    print("=" * 60)
