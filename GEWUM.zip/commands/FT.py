"""
GEWUM FT (Fine-Tuning) Workflow Command
Active learning data preparation via uncertainty estimation
"""
import os
import shutil
from ..config import FT_REPOSITORY

FT_FILE_MAP = {
    "prepare": ["run_ft.sh"],
}

MODE_DESCRIPTIONS = """
  prepare: Uncertainty estimation for active learning data preparation
           - Input: Relaxed CIF files in current directory
           - Output: ft_uncertainty.csv + ft_dft_candidates/
"""


def setup_args(parser):
    """Configure command arguments"""
    all_modes = list(FT_FILE_MAP.keys())
    
    parser.add_argument(
        "--mode", 
        required=True,
        choices=all_modes,
        help=f"GEWUM FT mode to copy:\n{MODE_DESCRIPTIONS}"
    )
    parser.add_argument(
        "--dest", 
        default=".",
        help="Target directory (default: current directory)"
    )


def execute(args):
    """Execute the FT workflow command"""
    from .base import BaseWorkflowCommand
    
    class FTCommand(BaseWorkflowCommand):
        @property
        def repository_path(self):
            return FT_REPOSITORY
        
        @property
        def file_map(self):
            return FT_FILE_MAP
        
        @property
        def workflow_name(self):
            return "FT"
    
    cmd = FTCommand()
    cmd.execute(args)
