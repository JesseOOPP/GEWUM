"""
GEWUM FT (Fine-Tuning) Module - Uncertainty Estimation
Evaluate structure uncertainty via perturbation-based energy sampling
to select candidates for DFT calculations.

Usage:
    python ft_uncertainty.py [options]

Input: Relaxed CIF files in current directory (from RD workflow)
Output: 
    - ft_uncertainty.csv: All structures with uncertainty values
    - ft_dft_candidates/: High-uncertainty CIF files for DFT
"""
import os
import glob
import shutil
import argparse
import numpy as np
from concurrent.futures import ProcessPoolExecutor, as_completed
from ase.io import read, write
try:
    from mattersim.forcefield import MatterSimCalculator
except ImportError:
    from mattersim.forcefield.potential import MatterSimCalculator


def process_single_cif(args_tuple):
    """
    Process a single CIF file for uncertainty estimation.
    Designed for parallel execution.
    
    Args:
        args_tuple: (cif_file, n_samples, perturbation_std)
    
    Returns:
        dict with results or None on error
    """
    cif_file, n_samples, perturbation_std = args_tuple
    
    try:
        calc = MatterSimCalculator()
        
        atoms = read(cif_file)
        n_atoms = len(atoms)
        
        atoms.calc = calc
        original_energy = atoms.get_potential_energy()
        original_energy_per_atom = original_energy / n_atoms
        
        unc_result = calculate_uncertainty(
            atoms, calc,
            n_samples=n_samples,
            perturbation_std=perturbation_std
        )
        
        return {
            'filename': cif_file,
            'n_atoms': n_atoms,
            'energy_per_atom': original_energy_per_atom,
            'energy_unc': unc_result['energy_unc'],
            'force_unc': unc_result['force_unc'],
            'force_unc_max': unc_result['force_unc_max'],
            'energy_std': unc_result['energy_std'],
            'status': 'success'
        }
    except Exception as e:
        return {
            'filename': cif_file,
            'status': 'error',
            'error_msg': str(e)
        }


def calculate_uncertainty(atoms, calculator, n_samples=10, perturbation_std=0.01):
    """
    Calculate uncertainty by perturbing structure and measuring energy/force variance.
    
    Args:
        atoms: ASE Atoms object (relaxed structure)
        calculator: ML potential calculator
        n_samples: Number of perturbation samples
        perturbation_std: Standard deviation of perturbation in Angstrom
    
    Returns:
        dict with energy and force uncertainty metrics
    """
    original_positions = atoms.positions.copy()
    energies = []
    all_forces = []
    
    for _ in range(n_samples):
        noise = np.random.normal(0, perturbation_std, atoms.positions.shape)
        atoms.positions = original_positions + noise
        
        atoms.calc = calculator
        energy = atoms.get_potential_energy()
        forces = atoms.get_forces()
        
        energies.append(energy)
        all_forces.append(forces)
    
    atoms.positions = original_positions
    
    energies = np.array(energies)
    all_forces = np.array(all_forces)
    n_atoms = len(atoms)
    
    energy_unc = np.std(energies) / n_atoms
    
    force_magnitudes = np.linalg.norm(all_forces, axis=2)
    force_std_per_atom = np.std(force_magnitudes, axis=0)
    force_unc = np.mean(force_std_per_atom)
    force_unc_max = np.max(force_std_per_atom)
    
    return {
        'energy_mean': np.mean(energies),
        'energy_std': np.std(energies),
        'energy_unc': energy_unc,
        'force_unc': force_unc,
        'force_unc_max': force_unc_max,
        'force_std_per_atom': force_std_per_atom
    }


def main():
    parser = argparse.ArgumentParser(
        description='FT Uncertainty Estimation for Active Learning',
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument('--n-samples', '-n', type=int, default=10,
                        help='Number of perturbation samples (default: 10)')
    parser.add_argument('--perturbation', '-p', type=float, default=0.01,
                        help='Perturbation std in Angstrom (default: 0.01)')
    parser.add_argument('--threshold', '-t', type=float, default=0.01,
                        help='Energy uncertainty threshold (eV/atom, default: 0.01)')
    parser.add_argument('--force-threshold', '-f', type=float, default=0.1,
                        help='Force uncertainty threshold (eV/AA, default: 0.1)')
    parser.add_argument('--metric', '-m', choices=['energy', 'force', 'combined'], default='combined',
                        help='Selection metric: energy, force, or combined (default: combined)')
    parser.add_argument('--top-n', type=int, default=None,
                        help='Select top N high-uncertainty structures (overrides thresholds)')
    parser.add_argument('--weight-energy', '-we', type=float, default=0.5,
                        help='Weight for energy uncertainty in combined metric (default: 0.5)')
    parser.add_argument('--weight-force', '-wf', type=float, default=0.5,
                        help='Weight for force uncertainty in combined metric (default: 0.5)')
    parser.add_argument('--combined-threshold', '-c', type=float, default=1.0,
                        help='Combined uncertainty threshold (default: 1.0)')
    parser.add_argument('--workers', '-w', type=int, default=1,
                        help='Number of parallel workers (default: 1)')
    parser.add_argument('--output-dir', '-o', default='ft_dft_candidates',
                        help='Output directory for DFT candidate CIFs')
    parser.add_argument('--input-pattern', '-i', default='*.cif',
                        help='Input CIF file pattern (default: *.cif)')
    args = parser.parse_args()
    
    print("=" * 60)
    print("GEWUM FT - Uncertainty Estimation (Energy + Force)")
    print("=" * 60)
    print(f"Perturbation samples: {args.n_samples}")
    print(f"Perturbation std: {args.perturbation} AA")
    print(f"Selection metric: {args.metric}")
    if args.metric == 'energy':
        print(f"Energy threshold: {args.threshold} eV/atom")
    elif args.metric == 'force':
        print(f"Force threshold: {args.force_threshold} eV/AA")
    else:  # combined
        print(f"Weights: energy={args.weight_energy}, force={args.weight_force}")
        print(f"Combined threshold: {args.combined_threshold}")
    print(f"Parallel workers: {args.workers}")
    print("=" * 60)
    
    cif_files = glob.glob(args.input_pattern)
    if not cif_files:
        print(f"No CIF files found matching '{args.input_pattern}'")
        return
    
    print(f"Found {len(cif_files)} CIF files")
    
    task_args = [(cif, args.n_samples, args.perturbation) for cif in cif_files]
    
    results = []
    success_count = 0
    error_count = 0
    
    if args.workers == 1:
        print("\nProcessing sequentially...")
        calc = MatterSimCalculator()
        for idx, cif_file in enumerate(cif_files):
            print(f"[{idx+1}/{len(cif_files)}] {cif_file}", end=" ")
            try:
                atoms = read(cif_file)
                n_atoms = len(atoms)
                atoms.calc = calc
                original_energy = atoms.get_potential_energy()
                original_energy_per_atom = original_energy / n_atoms
                
                unc_result = calculate_uncertainty(
                    atoms, calc,
                    n_samples=args.n_samples,
                    perturbation_std=args.perturbation
                )
                
                result = {
                    'filename': cif_file,
                    'n_atoms': n_atoms,
                    'energy_per_atom': original_energy_per_atom,
                    'energy_unc': unc_result['energy_unc'],
                    'force_unc': unc_result['force_unc'],
                    'force_unc_max': unc_result['force_unc_max'],
                    'energy_std': unc_result['energy_std']
                }
                results.append(result)
                success_count += 1
                print(f"E_unc={unc_result['energy_unc']:.5f}, F_unc={unc_result['force_unc']:.5f}")
            except Exception as e:
                error_count += 1
                print(f"Error: {e}")
    else:
        print(f"\nProcessing with {args.workers} workers...")
        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            futures = {executor.submit(process_single_cif, arg): arg[0] for arg in task_args}
            
            for future in as_completed(futures):
                cif_file = futures[future]
                result = future.result()
                
                if result['status'] == 'success':
                    del result['status']
                    results.append(result)
                    success_count += 1
                    print(f"[{success_count + error_count}/{len(cif_files)}] {cif_file}: "
                          f"E_unc={result['energy_unc']:.5f}, F_unc={result['force_unc']:.5f}")
                else:
                    error_count += 1
                    print(f"[{success_count + error_count}/{len(cif_files)}] {cif_file}: Error - {result['error_msg']}")
    
    print(f"\nProcessed: {success_count} success, {error_count} errors")
    
    if not results:
        print("\nNo structures processed successfully.")
        return
    
    w_e = args.weight_energy
    w_f = args.weight_force
    for r in results:
        e_norm = r['energy_unc'] / args.threshold
        f_norm = r['force_unc'] / args.force_threshold
        r['combined_unc'] = w_e * e_norm + w_f * f_norm
    results.sort(key=lambda x: x['combined_unc'], reverse=True)
    
    csv_file = 'ft_uncertainty.csv'
    with open(csv_file, 'w') as f:
        f.write("Filename,N_Atoms,Energy_per_Atom(eV),Energy_Unc(eV/atom),Force_Unc(eV/A),Force_Unc_Max(eV/A),Combined_Unc\n")
        for r in results:
            f.write(f"{r['filename']},{r['n_atoms']},{r['energy_per_atom']:.6f},"
                    f"{r['energy_unc']:.6f},{r['force_unc']:.6f},{r['force_unc_max']:.6f},{r['combined_unc']:.4f}\n")
    print(f"\nResults saved to: {csv_file}")
    
    if args.top_n:
        candidates = results[:args.top_n]
        selection_method = f"top {args.top_n} by combined uncertainty"
    elif args.metric == 'energy':
        candidates = [r for r in results if r['energy_unc'] >= args.threshold]
        selection_method = f"energy_unc >= {args.threshold} eV/atom"
    elif args.metric == 'force':
        candidates = [r for r in results if r['force_unc'] >= args.force_threshold]
        selection_method = f"force_unc >= {args.force_threshold} eV/AA"
    else:  
        candidates = [r for r in results if r['combined_unc'] >= args.combined_threshold]
        selection_method = f"combined_unc >= {args.combined_threshold} (w_e={w_e}, w_f={w_f})"
    
    print(f"\n{'=' * 60}")
    print(f"DFT Candidates Selection ({selection_method})")
    print(f"{'=' * 60}")
    print(f"Selected {len(candidates)} / {len(results)} structures")
    
    if candidates:
        os.makedirs(args.output_dir, exist_ok=True)
        
        candidate_list_file = os.path.join(args.output_dir, 'candidate_list.csv')
        with open(candidate_list_file, 'w') as f:
            f.write("Filename,Energy_per_Atom(eV),Energy_Unc(eV/atom),Force_Unc(eV/A),Combined_Unc\n")
            for r in candidates:
                f.write(f"{r['filename']},{r['energy_per_atom']:.6f},{r['energy_unc']:.6f},"
                        f"{r['force_unc']:.6f},{r['combined_unc']:.4f}\n")
                src = r['filename']
                dst = os.path.join(args.output_dir, os.path.basename(src))
                shutil.copy(src, dst)
        
        print(f"\nCandidate CIFs copied to: {args.output_dir}/")
        print(f"Candidate list saved to: {candidate_list_file}")
        
        print(f"\n{'=' * 60}")
        print("Top 10 High-Uncertainty Structures:")
        print(f"{'=' * 60}")
        print(f"{'Rank':<5}{'Filename':<35}{'E_unc':<12}{'F_unc':<12}{'Combined':<10}")
        print("-" * 74)
        for i, r in enumerate(candidates[:10]):
            print(f"{i+1:<5}{r['filename']:<35}{r['energy_unc']:.5f}     "
                  f"{r['force_unc']:.5f}     {r['combined_unc']:.3f}")
    else:
        print("\nNo structures meet the selection criteria.")
        print("Consider lowering --threshold or using --top-n")
    
    print(f"\n{'=' * 60}")
    print("FT Uncertainty Estimation Complete")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
