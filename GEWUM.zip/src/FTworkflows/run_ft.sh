#!/bin/bash

#SBATCH --job-name={{JOB_NAME}}
#SBATCH --output={{JOB_NAME}}.out
#SBATCH --error={{JOB_NAME}}.err
#SBATCH --time={{SLURM_TIME}}
#SBATCH --cpus-per-task={{SLURM_CPUS}}
#SBATCH -p {{SLURM_PARTITION}}
#SBATCH -N {{SLURM_NODES}}

# ============================================================
# GEWUM FT - Uncertainty Estimation for Active Learning
# Select high-uncertainty structures as DFT candidates
# ============================================================

# Configuration - modify these parameters as needed
N_SAMPLES=10                    # Number of perturbation samples
PERTURBATION=0.01               # Perturbation std in Angstrom
METRIC="combined"               # Selection metric: energy, force, combined
WEIGHT_ENERGY=0.5               # Weight for energy uncertainty
WEIGHT_FORCE=0.5                # Weight for force uncertainty

# Thresholds (used based on METRIC)
ENERGY_THRESHOLD=0.01           # Energy uncertainty threshold (eV/atom)
FORCE_THRESHOLD=0.1             # Force uncertainty threshold (eV/AA)
COMBINED_THRESHOLD=1.0          # Combined uncertainty threshold

# Selection options (choose one)
TOP_N=                          # Select top N structures (leave empty to use threshold)

# Parallel settings
WORKERS=64                      # Number of parallel workers

# Input/Output
INPUT_PATTERN="*.cif"           # Input CIF file pattern
OUTPUT_DIR="ft_dft_candidates"  # Output directory for selected CIFs

# ============================================================

start_time=$(date +%s)

echo "============================================================"
echo "GEWUM FT - Uncertainty Estimation"
echo "============================================================"
echo "N_SAMPLES: $N_SAMPLES"
echo "PERTURBATION: $PERTURBATION Å"
echo "METRIC: $METRIC"
echo "WORKERS: $WORKERS"
if [ "$METRIC" = "energy" ]; then
    echo "ENERGY_THRESHOLD: $ENERGY_THRESHOLD eV/atom"
elif [ "$METRIC" = "force" ]; then
    echo "FORCE_THRESHOLD: $FORCE_THRESHOLD eV/AA"
else
    echo "WEIGHTS: energy=$WEIGHT_ENERGY, force=$WEIGHT_FORCE"
    echo "COMBINED_THRESHOLD: $COMBINED_THRESHOLD"
fi
if [ -n "$TOP_N" ]; then
    echo "TOP_N: $TOP_N (overrides threshold)"
fi
echo "INPUT_PATTERN: $INPUT_PATTERN"
echo "OUTPUT_DIR: $OUTPUT_DIR"
echo "============================================================"

{{ENV_SETUP}}

CMD="python -m gewum.src.FTworkflows.ft_uncertainty \
    --n-samples $N_SAMPLES \
    --perturbation $PERTURBATION \
    --metric $METRIC \
    --workers $WORKERS \
    --input-pattern \"$INPUT_PATTERN\" \
    --output-dir $OUTPUT_DIR"

if [ "$METRIC" = "energy" ]; then
    CMD="$CMD --threshold $ENERGY_THRESHOLD"
elif [ "$METRIC" = "force" ]; then
    CMD="$CMD --force-threshold $FORCE_THRESHOLD"
else
    CMD="$CMD --weight-energy $WEIGHT_ENERGY"
    CMD="$CMD --weight-force $WEIGHT_FORCE"
    CMD="$CMD --combined-threshold $COMBINED_THRESHOLD"
fi

if [ -n "$TOP_N" ]; then
    CMD="$CMD --top-n $TOP_N"
fi

echo "Running: $CMD"
echo "============================================================"

eval $CMD

end_time=$(date +%s)
elapsed_time=$((end_time - start_time))
hours=$((elapsed_time / 3600))
minutes=$(((elapsed_time % 3600) / 60))
seconds=$((elapsed_time % 60))

echo "============================================================"
echo "FT Uncertainty Estimation completed!"
echo "Total runtime: ${hours}h ${minutes}m ${seconds}s"
echo "Results: ft_uncertainty.csv"
echo "DFT candidates: $OUTPUT_DIR/"
echo "============================================================"
