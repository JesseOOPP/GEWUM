# CIF generation input module
