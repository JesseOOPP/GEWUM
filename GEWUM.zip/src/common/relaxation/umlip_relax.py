"""
GEWUM Unified Structure Relaxation Module
Supports RD (Random Design), PT (Perturbation), and HP (High Pressure) workflows
"""
import os
import logging
import csv
import gc
import argparse
from ase.io import read, write
from ase.optimize import BFGS, LBFGS
from ase.filters import UnitCellFilter
try:
    from mattersim.forcefield import MatterSimCalculator
except ImportError:
    from mattersim.forcefield.potential import MatterSimCalculator
#from upet.calculator import UPETCalculator
#from deepmd.calculator import DP as DPCalculator

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

GPA_TO_EV_PER_ANG3 = 1 / 160.21766208  # 1 GPa = 1/160.2177 eV/AA3


def optimize_structure(cif_file, relaxed_dir, mode=1, fmax=0.05, max_steps=200, pressure=0.0):
    """
    Unified structure optimization function for GEWUM workflows.
    
    Args:
        cif_file: Path to input CIF file
        relaxed_dir: Directory to save relaxed structure
        mode: Optimization mode
            1 - Only atoms (BFGS, default for PT workflow)
            2 - Atoms and lattice a/b/c (LBFGS + UnitCellFilter, for RD workflow)
            3 - High pressure optimization (LBFGS + UnitCellFilter, for HP workflow)
        fmax: Force convergence threshold (default: 0.05 eV/AA)
        max_steps: Maximum optimization steps (default: 200)
        pressure: Target pressure in GPa (only used in mode 3, default: 0.0)
    
    Returns:
        csv_path: Path to the energy results CSV file
    """
    hp_data = None
    
    try:
        atoms = read(cif_file)
        device = "cpu"
        
        if mode == 3:
            logging.info(f"Running uMLIP on {device}, mode={mode} (HP), pressure={pressure} GPa, fmax={fmax}")
        else:
            logging.info(f"Running uMLIP on {device}, mode={mode}, fmax={fmax}")
        
        calculator = MatterSimCalculator(device=device)
        #calculator = UPETCalculator(checkpoint_path="pet-mad-s-v1.5.0.ckpt", device="cpu")
        #calculator = DPCalculator("Alex2D.pth")
        atoms.calc = calculator
        
        if mode == 1:
            dyn = BFGS(atoms)
            dyn.run(fmax=fmax, steps=max_steps)
        elif mode == 2:
            mask = [True, True, True, False, False, False]
            ucf = UnitCellFilter(atoms, mask=mask)
            dyn = LBFGS(ucf)
            dyn.run(fmax=fmax, steps=max_steps)
        elif mode == 3:
            target_pressure = pressure * GPA_TO_EV_PER_ANG3
            ucf = UnitCellFilter(atoms, scalar_pressure=target_pressure)
            dyn = LBFGS(ucf)
            dyn.run(fmax=fmax, steps=max_steps)
            atoms = ucf.atoms  
        else:
            raise ValueError(f"Unknown mode: {mode}. Use 1 (atoms only), 2 (atoms + cell), or 3 (high pressure).")
        
        optimized_energy = atoms.get_potential_energy()
        optimized_energy_per_atom = optimized_energy / len(atoms)
        
        if mode == 3 and pressure != 0.0:
            stress_voigt = atoms.calc.get_stress()  
            stress_voigt_GPa = stress_voigt * 160.21766208
            hydrostatic_pressure = -(stress_voigt_GPa[0] + stress_voigt_GPa[1] + stress_voigt_GPa[2]) / 3
            
            volume = atoms.get_volume()
            PV_term = hydrostatic_pressure * volume / 160.21766208
            enthalpy = optimized_energy + PV_term
            enthalpy_per_atom = enthalpy / len(atoms)
            
            dE_dPV = (pressure - hydrostatic_pressure) * volume / 160.21766208 / len(atoms)
            corrected_enthalpy_per_atom = enthalpy_per_atom + dE_dPV
            
            hp_data = {
                'final_pressure': hydrostatic_pressure,
                'enthalpy_per_atom': enthalpy_per_atom,
                'corrected_enthalpy_per_atom': corrected_enthalpy_per_atom,
                'dE_dPV': dE_dPV
            }
            logging.info(f"Target pressure: {pressure} GPa, Final pressure: {hydrostatic_pressure:.2f} GPa")
            logging.info(f"Corrected enthalpy: {corrected_enthalpy_per_atom:.6f} eV/atom")
        
        base_name = os.path.basename(cif_file).replace('.cif', '')
        outfile = os.path.join(relaxed_dir, f"{base_name}_relaxed.cif")
        write(outfile, atoms)
        
        csv_filename = "energy_results.csv"
        csv_path = os.path.join(os.path.dirname(relaxed_dir), csv_filename)
        
        file_exists = os.path.isfile(csv_path)
        with open(csv_path, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            if not file_exists:
                if mode == 3:
                    writer.writerow(['CIF_Base_Name', 'Total_Energy_eV', 'Energy_per_Atom_eV',
                                   'Final_Pressure_GPa', 'Enthalpy_per_Atom_eV', 
                                   'Corrected_Enthalpy_per_Atom_eV', 'Relaxed_CIF_Path'])
                else:
                    writer.writerow(['CIF_Base_Name', 'Total_Energy_eV', 
                                   'Energy_per_Atom_eV', 'Relaxed_CIF_Path'])
            
            if mode == 3 and hp_data:
                writer.writerow([base_name, optimized_energy, optimized_energy_per_atom,
                               hp_data['final_pressure'], hp_data['enthalpy_per_atom'],
                               hp_data['corrected_enthalpy_per_atom'], outfile])
            else:
                writer.writerow([base_name, optimized_energy, 
                               optimized_energy_per_atom, outfile])
        
        logging.info(f"Optimized structure saved to {outfile}")
        logging.info(f"Results appended to CSV: {csv_path}")
        
        return csv_path
        
    finally:
        if 'atoms' in locals():
            atoms.calc = None
        if 'calculator' in locals():
            del calculator
        if 'dyn' in locals():
            del dyn
        if mode in [2, 3] and 'ucf' in locals():
            del ucf
        gc.collect()


def main():
    """Command line interface for structure relaxation"""
    parser = argparse.ArgumentParser(
        description='GEWUM Structure Relaxation using MatterSim',
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument('cif_file', help='Path to input CIF file')
    parser.add_argument('relaxed_dir', help='Directory to save relaxed structure')
    parser.add_argument('--mode', type=int, default=1, choices=[1, 2, 3],
                        help='Optimization mode:\n'
                             '  1 = atoms only (BFGS, for PT workflow)\n'
                             '  2 = atoms + cell (LBFGS+UnitCellFilter, for RD workflow)\n'
                             '  3 = high pressure (LBFGS+UnitCellFilter, for HP workflow)')
    parser.add_argument('--fmax', type=float, default=0.05,
                        help='Force convergence threshold in eV/Å (default: 0.05)')
    parser.add_argument('--max-steps', type=int, default=200,
                        help='Maximum optimization steps (default: 200)')
    parser.add_argument('--pressure', type=float, default=0.0,
                        help='Target pressure in GPa (only for mode 3, default: 0.0)')
    
    args = parser.parse_args()
    
    if args.mode == 3 and args.pressure < 0:
        parser.error("--pressure must be non-negative when using mode 3 (high pressure)")
    
    os.makedirs(args.relaxed_dir, exist_ok=True)
    optimize_structure(args.cif_file, args.relaxed_dir, 
                      args.mode, args.fmax, args.max_steps, args.pressure)


if __name__ == "__main__":
    main()
