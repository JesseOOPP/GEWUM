"""
GEWUM Energy Hull Post-processing Module
Filter structures by energy above hull threshold and copy selected CIF files
"""
import pandas as pd
import os
import csv
from shutil import copy
import argparse
import sys


def filter_and_save_csv(input_file, output_file, threshold):
    """
    Filter structures by e_above_hull threshold.
    
    Args:
        input_file: Path to input CSV with e_above_hull column
        output_file: Path to save filtered results
        threshold: Maximum e_above_hull value (eV/atom)
    """
    df = pd.read_csv(input_file)
    filtered_df = df[df['e_above_hull'] < threshold]
    filtered_df.to_csv(output_file, index=False)
    print(f"Filtered {len(filtered_df)}/{len(df)} structures with e_above_hull < {threshold} eV")
    return filtered_df


def get_unique_filename(destination_path):
    """Generate unique filename to avoid overwriting"""
    base, ext = os.path.splitext(destination_path)
    counter = 1
    while os.path.exists(destination_path):
        destination_path = f"{base}_{counter}{ext}"
        counter += 1
    return destination_path


def process_compositions(input_file, output_dir):
    """
    Copy CIF files for filtered compositions.
    
    Args:
        input_file: Path to filtered CSV with Relaxed_CIF_Path column
        output_dir: Directory to copy CIF files to
    """
    os.makedirs(output_dir, exist_ok=True)
    
    copied_count = 0
    with open(input_file, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            source_path = row.get('Relaxed_CIF_Path', '').strip()
            if not source_path or not os.path.isfile(source_path):
                print(f"Warning: Invalid or missing Relaxed_CIF_Path: {source_path}")
                continue
            
            cif_filename = os.path.basename(source_path)
            dest_path = os.path.join(output_dir, cif_filename)
            unique_dest = get_unique_filename(dest_path)
            
            try:
                copy(source_path, unique_dest)
                copied_count += 1
                print(f"Copied: {source_path} -> {unique_dest}")
            except Exception as e:
                print(f"Error copying {source_path}: {e}")
    
    print(f"\nSuccessfully copied {copied_count} CIF files to {output_dir}")
    return copied_count


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description='Post-process energy hull results')
    parser.add_argument('--input', '-i', default='Hull_result.csv',
                        help='Input CSV file with hull results')
    parser.add_argument('--output', '-o', default='final_result_02.csv',
                        help='Output filtered CSV file')
    parser.add_argument('--threshold', '-t', type=float, default=0.2,
                        help='E_above_hull threshold in eV/atom (default: 0.2)')
    parser.add_argument('--cif-dir', '-d', default='0_cif',
                        help='Directory to copy selected CIF files')
    parser.add_argument('-N', '--no-hull', action='store_true',
                        help='Skip hull filtering, extract all CIFs from 0_final_result_tot.txt directly')
    parser.add_argument('--raw-input', default='0_final_result_tot.txt',
                        help='Raw input file for -N mode (default: 0_final_result_tot.txt)')
    args = parser.parse_args()
    
    if args.no_hull:
        if not os.path.exists(args.raw_input):
            print(f"Error: Input file not found: {args.raw_input}")
            sys.exit(1)
        print(f"Mode: No hull filtering. Extracting all CIFs from {args.raw_input}")
        process_compositions(args.raw_input, args.cif_dir)
    else:
        filter_and_save_csv(args.input, args.output, args.threshold)
        process_compositions(args.output, args.cif_dir)


if __name__ == "__main__":
    main()
