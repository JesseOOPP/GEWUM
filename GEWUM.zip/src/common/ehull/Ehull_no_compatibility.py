"""GEWUM Energy Hull Calculation Module (without compatibility corrections)
Simplified calculation using raw energies
Supports both online (MP API) and offline (local JSON) modes
"""
import logging
from pymatgen.analysis.phase_diagram import PDEntry, PhaseDiagram
import re
import pandas as pd
import numpy as np
from collections import defaultdict
import argparse
import time

logging.basicConfig(
    filename='process.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


def get_above_hull_and_formation_energy(file_path, mp_api_key=None, mp_data_path=None):
    """
    Calculate energy above hull without compatibility corrections.
    
    Args:
        file_path: Path to CSV file with formula and energy columns
        mp_api_key: Materials Project API key (for online mode)
        mp_data_path: Path to offline MP JSON file (for offline mode)
        
    Note:
        Either mp_api_key or mp_data_path must be provided.
        If mp_data_path is provided, offline mode is used.
    
    Returns:
        Tuple of (phase_diagram_objects, formula_energy_dict, result_dataframe)
    """
    # Validate arguments
    if not mp_api_key and not mp_data_path:
        raise ValueError("Either mp_api_key or mp_data_path must be provided")
    
    use_offline = mp_data_path is not None
    
    data = pd.read_csv(file_path, sep=',')

    formulas = data.iloc[:, 0].tolist()
    total_energies = data.iloc[:, 2].tolist()

    if len(formulas) != len(total_energies):
        raise ValueError("Mismatch between number of formulas and energies.")

    unique_formulas = set(formulas)
    element_systems = defaultdict(list)
    for formula in unique_formulas:
        elements = set(re.findall(r'[A-Z][a-z]*', formula))
        sorted_elements = '-'.join(sorted(elements))
        element_systems[sorted_elements].append(formula)

    mp_entries_cache = {}
    
    # Load MP entries (offline or online mode)
    if use_offline:
        logging.info("Using offline mode with local MP data")
        from .mp_offline_loader import MPOfflineLoader
        loader = MPOfflineLoader(mp_data_path)
        
        for element_system in element_systems.keys():
            logging.info(f"Loading entries for: {element_system}")
            try:
                entries = loader.get_entries_in_chemsys(element_system.split('-'), as_pd_entry=True)
                mp_entries_cache[element_system] = entries
                logging.info(f"Found {len(entries)} entries for {element_system}")
            except Exception as e:
                logging.error(f"Error loading {element_system}: {e}")
                mp_entries_cache[element_system] = []
    else:
        logging.info("Using online mode with MP API")
        try:
            from mp_api.client import MPRester
        except ImportError:
            from pymatgen.ext.matproj import MPRester
        
        with MPRester(mp_api_key) as mpr:
            for element_system in element_systems.keys():
                logging.info(f"Fetching MP entries for system: {element_system}")
                try:
                    entries = mpr.get_entries_in_chemsys(element_system)
                    mp_entries_cache[element_system] = entries
                    logging.info(f"Found {len(entries)} MP entries for {element_system}")
                    time.sleep(1.5)
                except Exception as e:
                    logging.error(f"Error fetching {element_system}: {e}")
                    mp_entries_cache[element_system] = []

    formation_energies = []
    e_above_hulls = []
    pd_objects = []

    for formula, total_energy in zip(formulas, total_energies):
        elements = set(re.findall(r'[A-Z][a-z]*', formula))
        element_system = '-'.join(sorted(elements))

        if element_system not in mp_entries_cache or not mp_entries_cache[element_system]:
            logging.warning(f"No MP entries for system {element_system}")
            formation_energies.append(np.nan)
            e_above_hulls.append(np.nan)
            pd_objects.append(None)
            continue

        base_entries = mp_entries_cache[element_system]
        try:
            current_entry = PDEntry(composition=formula, energy=total_energy)
            all_entries = base_entries + [current_entry]
            pd_calc = PhaseDiagram(all_entries)
            formation_energy = pd_calc.get_form_energy_per_atom(current_entry)
            e_above_hull = pd_calc.get_e_above_hull(current_entry)

            formation_energies.append(formation_energy)
            e_above_hulls.append(e_above_hull)
            pd_objects.append(pd_calc)

            logging.info(
                f"{formula}: Formation energy = {formation_energy:.4f} eV/atom, "
                f"E_above_hull = {e_above_hull:.4f} eV/atom"
            )
        except Exception as e:
            logging.error(f"Error processing {formula}: {e}")
            formation_energies.append(np.nan)
            e_above_hulls.append(np.nan)
            pd_objects.append(None)

    data['formation_energy_per_atom'] = formation_energies
    data['e_above_hull'] = e_above_hulls

    formula_energy_dict = dict(zip(formulas, total_energies)) 

    return pd_objects, formula_energy_dict, data


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description='Calculate energy above hull (no compatibility)')
    parser.add_argument('--input', '-i', default='0_final_result_tot.txt',
                        help='Input CSV file path')
    parser.add_argument('--output', '-o', default='Hull_result.csv',
                        help='Output CSV file path')
    parser.add_argument('--api-key',
                        help='Materials Project API key (for online mode)')
    parser.add_argument('--mp-data',
                        help='Path to offline MP JSON file (for offline mode)')
    args = parser.parse_args()
    
    # Validate arguments
    if not args.api_key and not args.mp_data:
        parser.error("Either --api-key or --mp-data must be provided")

    pd_objs, energy_dict, result_data = get_above_hull_and_formation_energy(
        file_path=args.input,
        mp_api_key=args.api_key,
        mp_data_path=args.mp_data
    )

    result_data.to_csv(args.output, index=False)
    logging.info("Processing completed successfully")
    print(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
