"""GEWUM Energy Hull Calculation Module (with MP2020 Compatibility)
Calculate formation energy and energy above hull using Materials Project data
Supports both online (MP API) and offline (local JSON) modes
"""
import logging
from pymatgen.analysis.phase_diagram import PhaseDiagram
from pymatgen.entries.compatibility import MaterialsProject2020Compatibility
from pymatgen.entries.computed_entries import ComputedEntry 
from pymatgen.core.composition import Composition 
import pandas as pd
import numpy as np
from collections import defaultdict
import warnings
import argparse
import time
import os

warnings.filterwarnings("ignore", category=UserWarning, module='mp_api.client.core.client')

logging.basicConfig(filename='process.log', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# MP2020 POTCAR symbol mapping
POTCAR_MAP = {
    "Ac": "Ac", "Ag": "Ag", "Al": "Al", "Am": "Am", "Ar": "Ar", 
    "As": "As", "At": "At", "Au": "Au", "B": "B", "Ba": "Ba_sv", 
    "Be": "Be_sv", "Bi": "Bi", "Br": "Br", "C": "C", "Ca": "Ca_sv", 
    "Cd": "Cd", "Ce": "Ce", "Cf": "Cf", "Cl": "Cl", "Cm": "Cm", 
    "Co": "Co", "Cr": "Cr_pv", "Cs": "Cs_sv", "Cu": "Cu_pv", 
    "Dy": "Dy_3", "Er": "Er_3", "Eu": "Eu", "F": "F", "Fe": "Fe_pv", 
    "Fr": "Fr_sv", "Ga": "Ga_d", "Gd": "Gd", "Ge": "Ge_d", "H": "H", 
    "He": "He", "Hf": "Hf_pv", "Hg": "Hg", "Ho": "Ho_3", "I": "I", 
    "In": "In_d", "Ir": "Ir", "K": "K_sv", "Kr": "Kr", "La": "La", 
    "Li": "Li_sv", "Lu": "Lu_3", "Mg": "Mg_pv", "Mn": "Mn_pv", 
    "Mo": "Mo_pv", "N": "N", "Na": "Na_pv", "Nb": "Nb_pv", 
    "Nd": "Nd_3", "Ne": "Ne", "Ni": "Ni_pv", "Np": "Np", "O": "O", 
    "Os": "Os_pv", "P": "P", "Pa": "Pa", "Pb": "Pb_d", "Pd": "Pd", 
    "Pm": "Pm_3", "Po": "Po", "Pr": "Pr_3", "Pt": "Pt", "Pu": "Pu", 
    "Ra": "Ra_sv", "Rb": "Rb_sv", "Re": "Re_pv", "Rh": "Rh_pv", 
    "Rn": "Rn", "Ru": "Ru_pv", "S": "S", "Sb": "Sb", "Sc": "Sc_sv", 
    "Se": "Se", "Si": "Si", "Sm": "Sm_3", "Sn": "Sn_d", "Sr": "Sr_sv", 
    "Ta": "Ta_pv", "Tb": "Tb_3", "Tc": "Tc_pv", "Te": "Te", "Th": "Th", 
    "Ti": "Ti_pv", "Tl": "Tl_d", "Tm": "Tm_3", "U": "U", "V": "V_pv", 
    "W": "W_pv", "Xe": "Xe", "Y": "Y_sv", "Yb": "Yb_3", "Zn": "Zn", 
    "Zr": "Zr_sv"
}


def get_mp2020_potcar_symbols(element):
    """Get MP2020-compatible POTCAR symbol for an element"""
    return POTCAR_MAP.get(element, element)


def get_above_hull_and_formation_energy(file_path, mp_api_key=None, mp_data_path=None):
    """
    Calculate energy above hull and formation energy for compounds.
    
    Args:
        file_path: Path to CSV file with Chemical_Formula and Total_Energy_eV columns
        mp_api_key: Materials Project API key (for online mode)
        mp_data_path: Path to offline MP JSON file (for offline mode)
        
    Note:
        Either mp_api_key or mp_data_path must be provided.
        If mp_data_path is provided, offline mode is used.
    
    Returns:
        DataFrame with added formation_energy_per_atom, e_above_hull columns
    """
    # Validate arguments
    if not mp_api_key and not mp_data_path:
        raise ValueError("Either mp_api_key or mp_data_path must be provided")
    
    use_offline = mp_data_path is not None
    
    try:
        data = pd.read_csv(file_path, header=0)
        formulas = data['Chemical_Formula'].tolist()
        total_energies = data['Total_Energy_eV'].tolist()
        total_rows = len(data)
        logging.info(f"Loaded {total_rows} compounds from {file_path}")
    except Exception as e:
        logging.error(f"Loading error: {e}")
        raise

    formation_energies = [np.nan] * total_rows
    e_above_hulls = [np.nan] * total_rows
    correction_values = [np.nan] * total_rows
    status_messages = [""] * total_rows

    unique_formulas = set(formulas)
    element_systems = defaultdict(list)
    for formula in unique_formulas:
        try:
            comp = Composition(formula)
            elements = sorted([el.symbol for el in comp.elements])
            element_system = '-'.join(elements)
            element_systems[element_system].append(formula)
        except Exception as e:
            logging.warning(f"Failed to parse unique formula {formula}: {e}")
            continue

    mp_entries_cache = {}
    compatibility = MaterialsProject2020Compatibility()
    
    # Load MP entries (offline or online mode)
    if use_offline:
        logging.info("Using offline mode with local MP data")
        try:
            from .mp_offline_loader import MPOfflineLoader
            loader = MPOfflineLoader(mp_data_path)
        except ImportError as e:
            raise ImportError(f"Failed to import MPOfflineLoader for offline mode: {e}. "
                             f"Ensure mp_offline_loader.py is available.")
        
        for element_system in element_systems.keys():
            logging.info(f"Loading entries for: {element_system}")
            try:
                entries = loader.get_entries_in_chemsys(element_system.split('-'))
                mp_entries_cache[element_system] = entries
                logging.info(f"Found {len(entries)} entries for {element_system}")
            except Exception as e:
                logging.error(f"Error loading {element_system}: {e}")
                mp_entries_cache[element_system] = []
    else:
        logging.info("Using online mode with MP API")
        from mp_api.client import MPRester
        
        with MPRester(mp_api_key) as mpr:
            for element_system in element_systems.keys():
                logging.info(f"Fetching: {element_system}")
                try:
                    entries = mpr.get_entries_in_chemsys(element_system.split('-'))
                    processed_entries = []
                    for entry in entries:
                        if hasattr(entry, 'parameters') and 'potcar_symbols' in entry.parameters:
                            processed_entries.append(entry)
                        else:
                            try:
                                new_entry = ComputedEntry(
                                    composition=entry.composition,
                                    energy=entry.energy,
                                    entry_id=entry.entry_id,
                                    parameters=getattr(entry, 'parameters', {})
                                )
                                processed_entries.append(new_entry)
                            except Exception:
                                processed_entries.append(entry)
                    mp_entries_cache[element_system] = processed_entries
                    logging.info(f"Found {len(processed_entries)} entries for {element_system}")
                    time.sleep(1.5)
                except Exception as e:
                    logging.error(f"Error fetching {element_system}: {e}")
                    mp_entries_cache[element_system] = []

    for idx, (formula, total_energy) in enumerate(zip(formulas, total_energies)):
        try:
            comp = Composition(formula)
            elements = sorted([el.symbol for el in comp.elements])
            element_system = '-'.join(elements)

            base_entries = mp_entries_cache.get(element_system, [])
            if not base_entries:
                status_messages[idx] = f"No MP data for system: {element_system}"
                logging.warning(status_messages[idx])
                continue

            potcar_symbols = [get_mp2020_potcar_symbols(el.symbol) for el in comp.elements]
            current_entry = ComputedEntry(
                composition=comp,
                energy=total_energy,
                entry_id=f"CUSTOM_{idx}_{formula}",
                parameters={
                    "run_type": "GGA",
                    "is_hubbard": False,
                    "potcar_symbols": potcar_symbols,
                    "hubbards": {},
                    "potcar_spec": [{"titel": f"PAW_PBE {sym} 06Sep2000"} for sym in potcar_symbols]
                }
            )

            try:
                adjustments = compatibility.get_adjustments(current_entry)
                total_correction = sum(adj.value for adj in adjustments) if adjustments else 0.0
                correction_values[idx] = total_correction

                processed_entries = compatibility.process_entries([current_entry])
                if processed_entries:
                    current_entry = processed_entries[0]
                else:
                    raise ValueError("Compatibility processing returned empty list")
            except Exception as e:
                status_messages[idx] = f"Compatibility error: {e}"
                logging.warning(f"Compatibility error for {formula} (row {idx}): {e}")
                continue

            all_entries = base_entries + [current_entry]
            pd_calc = PhaseDiagram(all_entries)
            formation_energy = pd_calc.get_form_energy_per_atom(current_entry)
            e_above_hull = pd_calc.get_e_above_hull(current_entry)

            formation_energies[idx] = formation_energy
            e_above_hulls[idx] = e_above_hull
            status_messages[idx] = "Success"

            logging.info(f"Row {idx} {formula}: FE={formation_energy:.6f}, EH={e_above_hull:.6f}, corr={total_correction:.6f}")

        except Exception as e:
            status_messages[idx] = f"Processing error: {e}"
            logging.exception(f"Error at row {idx} ({formula}): {e}")

    data['formation_energy_per_atom'] = formation_energies
    data['e_above_hull'] = e_above_hulls
    data['energy_correction'] = correction_values
    data['status'] = status_messages

    return data


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description='Calculate energy above hull using MP compatibility')
    parser.add_argument('--input', '-i', default='0_final_result_tot.txt',
                        help='Input CSV file path')
    parser.add_argument('--output', '-o', default='Hull_result.csv',
                        help='Output CSV file path')
    parser.add_argument('--api-key',
                        help='Materials Project API key (for online mode)')
    parser.add_argument('--mp-data',
                        help='Path to offline MP JSON file (for offline mode)')
    args = parser.parse_args()
    
    # Validate arguments
    if not args.api_key and not args.mp_data:
        parser.error("Either --api-key or --mp-data must be provided")
    
    try:
        result_data = get_above_hull_and_formation_energy(
            file_path=args.input, 
            mp_api_key=args.api_key,
            mp_data_path=args.mp_data
        )
        result_data.to_csv(args.output, index=False)
        
        success_count = sum(result_data['status'] == "Success")
        logging.info(f"Processing completed: {success_count}/{len(result_data)} compounds successful")
        print(f"All Done. Successfully processed {success_count}/{len(result_data)} compounds")
    except Exception as e:
        logging.exception("Error")
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
