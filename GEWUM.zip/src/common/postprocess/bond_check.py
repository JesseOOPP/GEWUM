"""
GEWUM Bond Length Check Module
Identifies structures with abnormally short bond lengths after relaxation
"""
import os
import shutil
from pymatgen.io.cif import CifParser
from pymatgen.core.structure import Structure
import warnings
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

warnings.filterwarnings("ignore", message="Issues encountered while parsing CIF: .* fractional coordinates rounded to ideal values to avoid issues with finite precision.", category=UserWarning)


def calculate_min_bond_length(structure, search_radius=3.5):
    """
    Calculate the minimum bond length in a structure.
    
    Args:
        structure: pymatgen Structure object
        search_radius: Maximum distance to search for neighbors
    
    Returns:
        Minimum distance between any two atoms
    """
    min_distance = float('inf')
    for site in structure:
        neighbors = structure.get_neighbors(site, r=search_radius)  
        for neighbor in neighbors:
            distance = site.distance(neighbor[0])
            if distance < min_distance:
                min_distance = distance
    return min_distance


def process_relaxed_directory(relaxed_dir, min_bond_threshold=1.0):
    """
    Process a directory containing relaxed CIF files and move those with
    abnormally short bonds to a 'bond_mis' subdirectory.
    
    Args:
        relaxed_dir: Path to directory containing relaxed CIF files
        min_bond_threshold: Minimum acceptable bond length 
    """
    print(f"Processing directory: {relaxed_dir}")
    
    bond_mis_dir = os.path.join(relaxed_dir, 'bond_mis')
    if os.path.exists(bond_mis_dir):
        print(f"Skipping {relaxed_dir} because bond_mis directory already exists")
        return
    
    cif_files = [f for f in os.listdir(relaxed_dir) if f.endswith('_relaxed.cif')]
    
    for cif_file in cif_files:
        cif_path = os.path.join(relaxed_dir, cif_file)
        
        try:
            parser = CifParser(cif_path)
            structure = parser.parse_structures()[0]
            min_bond_length = calculate_min_bond_length(structure)
            
            if min_bond_length < min_bond_threshold:
                os.makedirs(bond_mis_dir, exist_ok=True)
                shutil.move(cif_path, os.path.join(bond_mis_dir, cif_file))
                print(f"Moved {cif_file} to bond_mis in {relaxed_dir} (min_bond={min_bond_length:.3f} )")
                
        except Exception as e:
            print(f"Error processing {cif_path}: {e}")


def find_relaxed_directories(base_dir='.'):
    """
    Find all 'relaxed' directories under the base directory.
    
    Args:
        base_dir: Base directory to search from
    
    Returns:
        List of paths to 'relaxed' directories
    """
    relaxed_dirs = []
    for root, dirs, files in os.walk(base_dir):
        relaxed_dir = os.path.join(root, 'relaxed')
        if os.path.isdir(relaxed_dir):
            relaxed_dirs.append(relaxed_dir)
    return relaxed_dirs


def main():
    """Main entry point for bond checking"""
    import argparse
    parser = argparse.ArgumentParser(description='GEWUM Bond Length Check')
    parser.add_argument('--threshold', '-t', type=float, default=1.0,
                        help='Minimum bond length threshold in Angstrom (default: 1.0)')
    parser.add_argument('--base-dir', '-d', default='.',
                        help='Base directory to search for relaxed directories (default: current directory)')
    args = parser.parse_args()
    
    relaxed_dirs = find_relaxed_directories(args.base_dir)
    print(f"Found {len(relaxed_dirs)} directories to process")
    print(f"Bond length threshold: {args.threshold} Angstrom")
    
    if 'SLURM_CPUS_PER_TASK' in os.environ:
        num_processes = int(os.environ['SLURM_CPUS_PER_TASK'])
    elif 'PBS_NUM_PPN' in os.environ:
        num_processes = int(os.environ['PBS_NUM_PPN'])
    else:
        num_processes = multiprocessing.cpu_count()
    
    num_processes = min(num_processes, len(relaxed_dirs)) if relaxed_dirs else 1
    
    print(f"Using {num_processes} processes for parallel processing")
    
    with ProcessPoolExecutor(max_workers=num_processes) as executor:
        future_to_dir = {
            executor.submit(process_relaxed_directory, dir_path, args.threshold): dir_path 
            for dir_path in relaxed_dirs
        }
        
        for future in as_completed(future_to_dir):
            dir_path = future_to_dir[future]
            try:
                future.result()
            except Exception as e:
                print(f"Error processing directory {dir_path}: {e}")


if __name__ == '__main__':
    main()
