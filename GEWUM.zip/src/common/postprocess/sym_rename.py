"""
GEWUM Symmetry Analysis and Renaming Module
Symmetrizes structures and renames CIF files based on space group and composition
"""
import os
import re
import shutil
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def symmetrize_and_save_cif(cif_file_path, output_dir, compound_name, symprec=0.02):
    """
    Symmetrize a structure and save it as a new CIF file.
    
    Args:
        cif_file_path: Path to input CIF file
        output_dir: Directory to save symmetrized structure
        compound_name: Base name for output file
        symprec: Symmetry precision for analysis
    
    Returns:
        Path to output file, or None if processing failed
    """
    try:
        parser = CifParser(cif_file_path)
        structures = parser.parse_structures(primitive=True)
        
        if not structures:
            raise ValueError("Invalid CIF file with no structures!")
            
        relaxed_cif = structures[0]
        
        spacegroup_analyzer = SpacegroupAnalyzer(relaxed_cif, symprec=symprec)
        symmetrized_cif = spacegroup_analyzer.get_symmetrized_structure()
        
        cif_writer = CifWriter(symmetrized_cif, symprec=symprec)
        output_path = os.path.join(output_dir, f"{compound_name}_symmetrized.cif")
        os.makedirs(output_dir, exist_ok=True)
        
        cif_writer.write_file(output_path)
        print(f'Symmetrized structure saved to: {output_path}')
        return output_path
        
    except Exception as e:
        print(f"Error processing {cif_file_path}: {str(e)}")
        return None


def rename_cif_files(directory):
    """
    Rename CIF files based on their space group and chemical formula.
    
    Args:
        directory: Directory containing CIF files to rename
    """
    for cif_file in os.listdir(directory):
        if not cif_file.endswith('.cif'):
            continue
            
        file_path = os.path.join(directory, cif_file)
        with open(file_path, 'r') as file:
            content = file.read()
            
            space_group_match = re.search(r'_symmetry_space_group_name_H-M\s+(.*)', content)
            chemical_formula_match = re.search(r'_chemical_formula_structural\s+(.*)', content)
            
            if not space_group_match or not chemical_formula_match:
                print(f"File '{cif_file}' skipped - missing required fields")
                continue
                
            space_group = space_group_match.group(1).strip().strip("'\"")
            chemical_formula = chemical_formula_match.group(1).strip().strip("'\"")
            
            illegal_chars = r'[\\/:*?"<>|\s]'
            space_group_clean = re.sub(illegal_chars, '_', space_group)
            chemical_formula_clean = re.sub(illegal_chars, '_', chemical_formula)
            
            space_group_clean = re.sub(r'_+', '_', space_group_clean)
            chemical_formula_clean = re.sub(r'_+', '_', chemical_formula_clean)
            
            base_filename = f"{space_group_clean}_{chemical_formula_clean}"
            new_filename = f"{base_filename}.cif"
            new_file_path = os.path.join(directory, new_filename)
            
            counter = 1
            while os.path.exists(new_file_path) and new_file_path != file_path:
                new_filename = f"{base_filename}_{counter}.cif"
                new_file_path = os.path.join(directory, new_filename)
                counter += 1
            
            if new_file_path != file_path:
                if os.path.exists(new_file_path):
                    print(f"Warning: Target file already exists: {new_file_path}, skipping rename")
                    continue
                try:
                    os.rename(file_path, new_file_path)
                    print(f"Renamed '{cif_file}' to '{os.path.basename(new_file_path)}'")
                except OSError as e:
                    print(f"Error renaming {cif_file}: {e}")
            else:
                print(f"File '{cif_file}' already has the correct name")


def move_error_file(cif_file_path, error_dir):
    """
    Move problematic CIF file to error directory.
    
    Args:
        cif_file_path: Path to the problematic file
        error_dir: Directory to move the file to
    """
    os.makedirs(error_dir, exist_ok=True)
    error_file_path = os.path.join(error_dir, os.path.basename(cif_file_path))
    
    counter = 1
    base_name = os.path.splitext(os.path.basename(cif_file_path))[0]
    extension = '.cif'
    
    while os.path.exists(error_file_path):
        error_file_path = os.path.join(error_dir, f"{base_name}_{counter}{extension}")
        counter += 1
    
    shutil.move(cif_file_path, error_file_path)
    print(f"Moved problematic file to: {error_file_path}")


def main(work_dir=None, symprec=0.02):
    """Main function to symmetrize and rename CIF files"""
    import argparse
    parser = argparse.ArgumentParser(description='GEWUM Symmetry Analysis and Renaming')
    parser.add_argument('--dir', '-d', default=None,
                        help='Working directory containing CIF files (default: current directory)')
    parser.add_argument('--symprec', '-s', type=float, default=0.02,
                        help='Symmetry precision for analysis (default: 0.02)')
    args = parser.parse_args()
    
    if args.dir:
        work_dir = args.dir
    elif work_dir is None:
        work_dir = os.getcwd()
    
    input_dir = work_dir
    output_dir = os.path.join(work_dir, 'relaxed_symmetry')
    error_dir = os.path.join(work_dir, 'error_str')
    
    processed_files = []
    error_files = []
    
    for filename in os.listdir(input_dir):
        if filename.endswith('.cif'):
            compound_name = os.path.splitext(filename)[0]
            cif_file_path = os.path.join(input_dir, filename)
            
            output_path = symmetrize_and_save_cif(cif_file_path, output_dir, compound_name)
            
            if output_path:
                processed_files.append(output_path)
            else:
                error_files.append(cif_file_path)
                move_error_file(cif_file_path, error_dir)
    
    print(f"\nProcessing summary:")
    print(f"Successfully processed: {len(processed_files)} files")
    print(f"Files with errors: {len(error_files)} files")
    
    if processed_files:
        print("\nStarting file renaming process...")
        rename_cif_files(output_dir)
        print("Renaming completed!")
    
    print("All files processed successfully!")


if __name__ == "__main__":
    main()
