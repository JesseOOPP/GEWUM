import numpy as np
from ase.io import read, write
from ase.optimize import BFGS
from ase.constraints import ExpCellFilter
from ase.units import GPa
try:
    from mattersim.forcefield import MatterSimCalculator
except ImportError:
    from mattersim.forcefield.potential import MatterSimCalculator

def relax(atoms, calc, pressure=0.0, maxstep=0.1, fmax=None, steps=None):
    atoms.calc = calc
    mask = [False, False, False, False, False, False] 
    ucf = ExpCellFilter(atoms, scalar_pressure=pressure*GPa, mask=mask, constant_volume=False)
    dyn = BFGS(ucf, maxstep=maxstep)
    dyn.run(fmax=fmax, steps=steps)
    return atoms

def main():
    import argparse
    parser = argparse.ArgumentParser(description='GEWUM ELA Single-point Calculation')
    parser.add_argument('--input', '-i', default='POSCAR', help='Input POSCAR file')
    parser.add_argument('--output', '-o', default='CONTCAR', help='Output CONTCAR file')
    parser.add_argument('--fmax', type=float, default=0.008, help='Force convergence threshold')
    parser.add_argument('--max-steps', type=int, default=300, help='Maximum optimization steps')
    parser.add_argument('--device', default='cpu', help='Device for calculation')
    args = parser.parse_args()
    
    model = read(args.input)
    
    print(f"Using MatterSim on {args.device} device")
    
    model_path = "MatterSim-v1.0.0-1M.pth" 
    MScalc = MatterSimCalculator(load_path=model_path, device=args.device)
    
    Relaxed_atoms = relax(
        atoms=model,
        calc=MScalc,
        pressure=0.0,
        maxstep=0.1,
        fmax=args.fmax,
        steps=args.max_steps
    )
    
    atom_force = Relaxed_atoms.get_forces()
    max_force = np.max(np.abs(atom_force))
    U_atom = Relaxed_atoms.get_potential_energy()
    
    if max_force <= args.fmax:
        print(f"  free  energy   TOTEN  = {U_atom:.6f} eV")
        print("                 Voluntary context switches:")
    else:
        print(f"Warning: Optimization did not fully converge! Max force: {max_force:.6f} eV/?")
    
    write(args.output, Relaxed_atoms, vasp5=True, direct=True)
    print(f"Optimized structure saved to {args.output}")


if __name__ == "__main__":
    main()
