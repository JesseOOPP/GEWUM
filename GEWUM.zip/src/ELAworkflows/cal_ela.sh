#!/bin/bash

#SBATCH --job-name={{JOB_NAME}}
#SBATCH --output={{JOB_NAME}}.out
#SBATCH --error={{JOB_NAME}}.err
#SBATCH --time={{SLURM_TIME}}
#SBATCH --cpus-per-task={{SLURM_CPUS}}
#SBATCH -p {{SLURM_PARTITION}}
#SBATCH -N {{SLURM_NODES}}

unset DISPLAY
start_time=$(date +%s)

{{ENV_SETUP}}

main_dir=$(pwd)

process_strain_calcs() {
    local subdir_path="$1"
    local main_dir="$2"
    
    cd "$subdir_path" || exit 1
    echo "Processing: $(pwd) on $(hostname)"
    
    temp_dir=$(mktemp -d -p . temp_XXXXXX)
    cd "$temp_dir" || exit 1
    
    ln -sf ../POSCAR ./
    python -m gewum.src.ELAworkflows.uMLIP_ela_sq > OUTCAR 2>&1
    
    cp OUTCAR  ..
    cp CONTCAR  ..

    cd ..
    rm -rf "$temp_dir"
    
    echo "Completed: $subdir_path"
}

export -f process_strain_calcs

for subdir in $(find . -maxdepth 1 -type d ! -path .); do
    dirname=$(basename "$subdir")
    
    cd "$subdir" || exit
    
    cp "${main_dir}/VPKIT.in1" .
    cp "${main_dir}/VPKIT.in2" .
    python -m gewum.src.ELAworkflows.cif_pri
    mv primitive_POSCAR POSCAR
    cp VPKIT.in1 VPKIT.in
    vaspkit -task 201
    
    cd "$main_dir" || exit
done

echo "Starting parallel processing of strain directories..."

find . -type d -name "strain_*" | parallel -j 64  --joblog parallel_joblog.txt \
    --retries 2 --delay 1 "process_strain_calcs {} '${main_dir}'"

if [ $? -ne 0 ]; then
    echo "Warning: Some parallel tasks may have failed. Check parallel_joblog.txt"
fi

for subdir in $(find . -maxdepth 1 -type d ! -path .); do
    dirname=$(basename "$subdir")
    
    cd "$subdir" || exit
    
    root_path=$(pwd)
    cd "$root_path" || exit 
    rm -f VPKIT.in
    cp VPKIT.in2 VPKIT.in
    vaspkit -task 201 > ela.dat 2>&1

    cd "$main_dir" || exit
done

echo "All done"

end_time=$(date +%s)
elapsed_time=$((end_time - start_time))
hours=$((elapsed_time / 3600))
minutes=$(((elapsed_time % 3600) / 60))
seconds=$((elapsed_time % 60))
echo "Total runtime: $hours hours, $minutes minutes, $seconds seconds" > Time_ela.log
