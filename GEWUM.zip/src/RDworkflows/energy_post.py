import os
import csv
import glob
import shutil
import argparse
from pymatgen.core import Structure

def main():
    parser = argparse.ArgumentParser(description='GEWUM Energy Post-processing')
    parser.add_argument('--gap', '-g', type=float, default=0.005,
                        help='Minimum energy difference between selected structures in eV/atom (default: 0.005)')
    parser.add_argument('--max-n', '-n', type=int, default=5,
                        help='Maximum number of structures to select (default: 5)')
    args = parser.parse_args()
    
    ENERGY_GAP = args.gap
    MAX_N = args.max_n
    
    current_dir = os.getcwd()
    chem_dir_name = os.path.basename(current_dir)
    output_dir = os.path.join(current_dir, '0_cif_final')
    os.makedirs(output_dir, exist_ok=True)

    csv_files = glob.glob(os.path.join(current_dir, '*', 'energy_results.csv'))
    all_data = []

    print(f"Found {len(csv_files)} CSV files:")
    for csv_file in csv_files:
        print(f"  - {csv_file}")

    with open(os.path.join(current_dir, 'energy_final.txt'), 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(['Chemical_Formula', 'CIF_Base_Name', 'Total_Energy_eV', 'Energy_per_Atom_eV', 'Relaxed_CIF_Path', 'SG_ori'])

        for csv_file in csv_files:
            space_group = os.path.basename(os.path.dirname(csv_file))
            print(f"Processing space group: {space_group}")

            try:
                with open(csv_file, 'r') as f:
                    reader = csv.reader(f)
                    try:
                        header = next(reader)
                    except StopIteration:
                        print(f"Warning: CSV file is empty: {csv_file}")
                        continue
                    print(f"CSV header: {header}")

                    for row in reader:
                        if len(row) < 4:
                            print(f"Skipping incomplete row: {row}")
                            continue

                        base_name = row[0].strip()
                        total_energy_str = row[1].strip()
                        energy_per_atom_str = row[2].strip()
                        cif_path = row[3].strip()

                        try:
                            total_energy = float(total_energy_str)
                            energy_per_atom = float(energy_per_atom_str)

                            if not os.path.exists(cif_path):
                                print(f"Warning: CIF file not found, skipping: {cif_path}")
                                continue

                            chemical_formula = "Unknown"
                            try:
                                structure = Structure.from_file(cif_path)
                                chemical_formula = structure.composition.formula.replace(" ", "")
                            except Exception as e:
                                print(f"Error reading CIF file {cif_path}: {e}")

                            writer.writerow([
                                chemical_formula,
                                base_name,
                                total_energy,
                                energy_per_atom,
                                cif_path,
                                space_group
                            ])

                            all_data.append({
                                'chemical_formula': chemical_formula,
                                'space_group': space_group,
                                'base_name': base_name,
                                'total_energy': total_energy,
                                'energy_per_atom': energy_per_atom,
                                'cif_path': cif_path
                            })

                        except ValueError as e:
                            print(f"Value conversion error: {e}, row data: {row}")
                            continue

            except Exception as e:
                print(f"Error processing file {csv_file}: {e}")
                continue

    if not all_data:
        print("No valid data found.")
        return

    all_data.sort(key=lambda x: x['energy_per_atom'])

    print(f"\nTotal entries: {len(all_data)}")
    print("First 10 energies:")
    for i, d in enumerate(all_data[:10]):
        print(f"{i+1}. {d['energy_per_atom']:.6f} eV/atom")

    selected_data = []
    last_energy = None

    for entry in all_data:
        if len(selected_data) >= MAX_N:
            break
        if last_energy is None:
            selected_data.append(entry)
            last_energy = entry['energy_per_atom']
        else:
            if entry['energy_per_atom'] - last_energy >= ENERGY_GAP:
                selected_data.append(entry)
                last_energy = entry['energy_per_atom']

    print(f"\nSelected {len(selected_data)} structures with energy gap >= {ENERGY_GAP} eV/atom:")

    result_path = os.path.join(current_dir, '0_final_results.txt')
    with open(result_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Chemical_Formula', 'CIF_Base_Name', 'Total_Energy_eV', 'Energy_per_Atom_eV', 'Relaxed_CIF_Path', 'SG_ori'])
        for data in selected_data:
            writer.writerow([
                data['chemical_formula'],
                data['base_name'],
                data['total_energy'],
                data['energy_per_atom'],
                data['cif_path'],
                data['space_group']
            ])

    for idx, data in enumerate(selected_data):
        src = data['cif_path']
        dst = os.path.join(
            output_dir,
            f"{chem_dir_name}_{data['chemical_formula']}_{data['space_group']}_{data['base_name']}_spaced_{idx+1}.cif"
        )
        if os.path.exists(src):
            shutil.copy(src, dst)
            print(f"Copied: {dst}")
        else:
            print(f"Warning: CIF not found: {src}")

    print("\nFinal selected structures:")
    for i, d in enumerate(selected_data):
        if i == 0:
            diff = 0.0
        else:
            diff = d['energy_per_atom'] - selected_data[i-1]['energy_per_atom']
        print(f"{i+1}. E = {d['energy_per_atom']:.6f} eV/atom (D = {diff:.6f}) | {d['chemical_formula']} | SG: {d['space_group']}")

if __name__ == "__main__":
    main()