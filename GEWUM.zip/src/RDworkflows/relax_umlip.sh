#!/bin/bash

#SBATCH --job-name={{JOB_NAME}}
#SBATCH --output={{JOB_NAME}}.out
#SBATCH --error={{JOB_NAME}}.err
#SBATCH --time={{SLURM_TIME}}
#SBATCH --cpus-per-task={{SLURM_CPUS}}
#SBATCH -p {{SLURM_PARTITION}}
#SBATCH -N {{SLURM_NODES}}

start_time=$(date +%s)

# Configurable parameters (can be overridden via command line)
MODE=${1:-1}           # 1=atoms only, 2=atoms+cell (default: 2 for RD)
FMAX=${2:-0.05}        # Force convergence threshold (eV/AA)
MAX_STEPS=${3:-200}    # Maximum optimization steps

echo "Optimization settings:"
echo "  MODE: $MODE"
echo "  FMAX: $FMAX eV/AA"
echo "  MAX_STEPS: $MAX_STEPS"

{{ENV_SETUP}}

top_dir=$(pwd)
echo "Top directory: $top_dir"

if [ ! -d "$top_dir" ]; then
    echo "Top directory does not exist: $top_dir"
    exit 1
fi

second_level_dirs=($(seq 2 230))

run_optimization() {
    CIF_FILE=$1
    RELAXED_DIR=$2
    OPT_MODE=$3
    OPT_FMAX=$4
    OPT_MAX_STEPS=$5

    echo "CIF_FILE: $CIF_FILE"
    echo "RELAXED_DIR: $RELAXED_DIR"
    
    if [ -z "$CIF_FILE" ] || [ -z "$RELAXED_DIR" ]; then
        echo "Error: CIF_FILE or RELAXED_DIR is empty. Skipping this task."
        return 1
    fi
    
    mkdir -p "$RELAXED_DIR"
    
    python -m gewum.src.common.relaxation.umlip_relax "$CIF_FILE" "$RELAXED_DIR" --mode "$OPT_MODE" --fmax "$OPT_FMAX" --max-steps "$OPT_MAX_STEPS" &>> cif_relax.out
    
    last_bfgs_line=$(grep '^BFGS:' cif_relax.out | tail -n 1)
    
    if [ -n "$last_bfgs_line" ]; then
        echo "$last_bfgs_line" >> cif_relax.out
    fi
}

export -f run_optimization

tasks_file="tasks.txt"
> "$tasks_file"

verbose=false
skip_count=0

for first_level_dir in $(ls "$top_dir"); do
    first_level_dir_path="$top_dir/$first_level_dir"
    if [ -d "$first_level_dir_path" ]; then
        $verbose && echo "First level directory exists: $first_level_dir_path"
        for second_level_dir in "${second_level_dirs[@]}"; do
            dir_path="$first_level_dir_path/$second_level_dir"
            if [ -d "$dir_path" ]; then
                $verbose && echo "Second level directory exists: $dir_path"
                for cif_file in $(ls "$dir_path" | grep '\.cif$'); do
                    cif_file_path="$dir_path/$cif_file"
                    relaxed_dir="$dir_path/relaxed"
                    base_name="${cif_file%.cif}"
                    relaxed_file="$relaxed_dir/${base_name}_relaxed.cif"

                    if [ -f "$relaxed_file" ]; then
                        $verbose && echo "[SKIP] Already relaxed: $cif_file"
                        skip_count=$((skip_count + 1))
                        continue
                    fi

                    if [ -n "$cif_file_path" ] && [ -n "$relaxed_dir" ]; then
                        echo "$cif_file_path $relaxed_dir" >> "$tasks_file"
                    else
                        echo "Error: CIF_FILE or RELAXED_DIR is empty. Skipping this task." >&2
                    fi
                done
            else
                $verbose && echo "Second level directory does not exist: $dir_path" >&2
            fi
        done
    elif [ -f "$first_level_dir_path" ]; then
        $verbose && echo "File found: $first_level_dir_path" >&2
    else
        $verbose && echo "Unknown item: $first_level_dir_path" >&2
    fi
done

echo "Already relaxed (skipped): $skip_count"

if [ ! -s "$tasks_file" ]; then
    echo "No tasks found."
    exit 1
fi

TOTAL_CPUS=${SLURM_CPUS_PER_TASK:-64}
CORES_PER_TASK=1
NUM_TASKS=$((TOTAL_CPUS / CORES_PER_TASK))

export OMP_NUM_THREADS=$CORES_PER_TASK  

parallel -j $NUM_TASKS  -a "$tasks_file" --colsep ' ' run_optimization {1} {2} $MODE $FMAX $MAX_STEPS

grep -c "Optimized" cif_relax.out  >> TOT_relaxed
rm  cif_relax.out 
end_time=$(date +%s)
elapsed_time=$((end_time - start_time))
hours=$((elapsed_time / 3600))
minutes=$(((elapsed_time % 3600) / 60))
seconds=$((elapsed_time % 60))
echo "Total runtime: $hours hours, $minutes minutes, $seconds seconds" > Time_cif_relax.log