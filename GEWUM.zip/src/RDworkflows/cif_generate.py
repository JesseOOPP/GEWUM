import logging
from pyxtal import pyxtal
import numpy as np
from pyxtal.msg import Comp_CompatibilityError
import os
from multiprocessing import Pool
import argparse
from ase.io import read, write

# Dimension
DIM_CONFIG = {
    0: {
        'name': 'point group',
        'groups': list(range(2, 57)),
        'default_max_atoms': 36,
        'from_random_kwargs': {'factor': 1},
        'add_vacuum': True,
    },
    1: {
        'name': 'rod group',
        'groups': list(range(2, 76)),
        'default_max_atoms': 36,
        'from_random_kwargs': {'factor': 1},
        'add_vacuum': False,
    },
    2: {
        'name': 'layer group',
        'groups': list(range(2, 81)),
        'default_max_atoms': 36,
        'from_random_kwargs': {'thickness': 3, 'factor': 1},
        'add_vacuum': False,
    },
    3: {
        'name': 'space group',
        'groups': list(range(2, 231)),
        'default_max_atoms': 36,
        'from_random_kwargs': {},
        'add_vacuum': False,
    },
}


def read_input_file(file_path, default_max_atoms):
    inputs = []
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            data = eval(line.strip())
            if len(data) == 3:
                elements, base_ratio, max_xtals = data
                max_atoms = default_max_atoms
            else:
                elements, base_ratio, max_xtals, max_atoms = data
            inputs.append((elements, base_ratio, int(max_xtals), max_atoms))
    return inputs


def create_folder(elements, base_ratio):
    folder_name = ''.join([f"{elem}{count}" for elem, count in zip(elements, base_ratio)])
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    return folder_name


def calculate_possible_ratios(base_ratio, max_atoms):
    possible_ratios = []
    for multiplicity in range(1, max_atoms // sum(base_ratio) + 1):
        atom_counts = tuple(x * multiplicity for x in base_ratio)
        if sum(atom_counts) <= max_atoms:
            possible_ratios.append(atom_counts)
    return possible_ratios


def add_vacuum_to_cif(input_path, output_path, vacuum=10.0):
    """Add vacuum to 0D structure and save as cif."""
    try:
        atoms = read(input_path, format='xyz')
        atoms.center(vacuum=vacuum)
        write(output_path, atoms, format='cif')
        return True
    except Exception as e:
        logging.error(f"Error processing {input_path}: {str(e)}")
        return False


def generate_crystals_for_group(args):
    elements, base_ratio, max_xtals, max_atoms, group, folder_name, max_attempts, dim, from_random_kwargs, group_name, add_vacuum, seed = args

    possible_ratios = calculate_possible_ratios(base_ratio, max_atoms)
    group_folder = os.path.join(folder_name, str(group))

    if not os.path.exists(group_folder):
        os.makedirs(group_folder)

    incompatible_ratios = []
    num_xtals = 0
    skip_group = False
    attempts = 0

    main_rng = np.random.default_rng(seed)

    while num_xtals < max_xtals and not skip_group and attempts < max_attempts:
        seed = main_rng.integers(0, 2**32)
        sub_rng = np.random.default_rng(seed)
        
        available_ratios = [ratio for ratio in possible_ratios if ratio not in incompatible_ratios]
        if not available_ratios:
            logging.warning(f"No more available ratios for {group_name} {group}. Skipping...")
            break
        
        atom_counts = available_ratios[sub_rng.integers(0, len(available_ratios))]
        
        try:
            xtal = pyxtal()
            xtal.from_random(dim, group, elements, atom_counts, random_state=sub_rng, **from_random_kwargs)
            
            if add_vacuum:
                temp_filename = os.path.join(group_folder, f'xtal_{num_xtals + 1}_temp.xyz')
                final_filename = os.path.join(group_folder, f'xtal_{num_xtals + 1}.cif')
                xtal.to_file(temp_filename)
                
                if add_vacuum_to_cif(temp_filename, final_filename, vacuum=10.0):
                    if os.path.exists(temp_filename):
                        os.remove(temp_filename)
                    num_xtals += 1
                    logging.info(f"Generated crystal {num_xtals}/{max_xtals} for {elements} {group_name} {group}")
                else:
                    logging.warning(f"Failed to add vacuum to {temp_filename}")
            else:
                filename = os.path.join(group_folder, f'xtal_{num_xtals + 1}.cif')
                xtal.to_file(filename)
                num_xtals += 1
                logging.info(f"Generated crystal {num_xtals}/{max_xtals} for {elements} {group_name} {group}")

        except (Comp_CompatibilityError, RuntimeError) as e:
            if "long time to generate structure" in str(e):
                logging.warning(f"{group_name.capitalize()} {group} skipped due to timeout: {str(e)}")
                skip_group = True
                break
            else:
                if atom_counts not in incompatible_ratios:
                    incompatible_ratios.append(atom_counts)
                logging.warning(f"Composition {atom_counts} incompatible for {elements} {group_name} {group}: {str(e)}")
        
        attempts += 1

    if attempts >= max_attempts:
        logging.warning(f"Reached maximum attempts ({max_attempts}) for {elements} {group_name} {group}")
    
    return f"Completed {elements} {group_name} {group}: {num_xtals}/{max_xtals} crystals"


def main():
    """Main entry point for crystal generation"""
    parser = argparse.ArgumentParser(description='Generate crystal structures for 0D/1D/2D/3D')
    parser.add_argument('--dim', type=int, required=True, choices=[0, 1, 2, 3],
                       help='Dimension: 0 (point groups), 1 (rod groups), 2 (layer groups), 3 (space groups)')
    parser.add_argument('--max-atoms', type=int, default=None,
                       help='Override maximum atoms for all compositions')
    parser.add_argument('--input-file', type=str, default='cifgen.inp',
                       help='Input file path (default: cifgen.inp)')
    parser.add_argument('--max-attempts', type=int, default=30,
                       help='Maximum attempts per group (default: 30)')
    parser.add_argument('--seed', type=int, default=None,
                       help='Random seed for reproducibility')
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    config = DIM_CONFIG[args.dim]
    group_name = config['name']
    groups = config['groups']
    default_max_atoms = config['default_max_atoms']
    from_random_kwargs = config['from_random_kwargs']
    add_vacuum = config['add_vacuum']

    inputs = read_input_file(args.input_file, default_max_atoms)

    if args.max_atoms is not None:
        inputs = [(elements, base_ratio, max_xtals, args.max_atoms) 
                 for elements, base_ratio, max_xtals, _ in inputs]

    if 'SLURM_CPUS_PER_TASK' in os.environ:
        max_workers_t = int(os.environ['SLURM_CPUS_PER_TASK'])
    else:
        max_workers_t = os.cpu_count()

    logging.info(f"Generating {args.dim}D crystals ({group_name}s {groups[0]}-{groups[-1]})")
    logging.info(f"Number of CPU cores to use: {max_workers_t}")

    tasks = []
    for elements, base_ratio, max_xtals, max_atoms in inputs:
        folder_name = create_folder(elements, base_ratio)
        for group in groups:
            tasks.append((elements, base_ratio, max_xtals, max_atoms, group, folder_name, 
                         args.max_attempts, args.dim, from_random_kwargs, group_name, add_vacuum, args.seed))

    logging.info(f"Total tasks to process: {len(tasks)}")
    logging.info(f"Starting parallel processing with {max_workers_t} workers")

    with Pool(max_workers_t) as pool:
        results = pool.map(generate_crystals_for_group, tasks)
        
        for result in results:
            logging.info(result)

    logging.info(f"All {args.dim}D crystals generated successfully.")


if __name__ == "__main__":
    main()
