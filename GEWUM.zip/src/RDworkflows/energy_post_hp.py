"""
GEWUM High Pressure Post-processing Module
Processes energy_results.csv from HP (mode 3) relaxation workflow
Filters by pressure tolerance and sorts by corrected enthalpy
"""
import os
import csv
import glob
import shutil
import argparse
from pymatgen.core import Structure


def main():
    """
    High pressure post-processing:
    1. Read energy_results.csv from each space group directory
    2. Filter structures by pressure tolerance
    3. Sort by corrected enthalpy (ascending)
    4. Select top structures with sufficient enthalpy gap
    """
    parser = argparse.ArgumentParser(description='High pressure post-processing')
    parser.add_argument('--pressure', type=float, default=100.0,
                        help='Target pressure in GPa (default: 100.0)')
    parser.add_argument('--tolerance', type=float, default=5.0,
                        help='Pressure tolerance in GPa (default: 5.0)')
    parser.add_argument('--gap', type=float, default=0.005,
                        help='Minimum enthalpy gap between selected structures in eV/atom (default: 0.005)')
    parser.add_argument('--max-n', type=int, default=5,
                        help='Maximum number of structures to select (default: 5)')
    args = parser.parse_args()
    
    TARGET_PRESSURE = args.pressure
    PRESSURE_TOLERANCE = args.tolerance
    ENTHALPY_GAP = args.gap
    MAX_N = args.max_n

    current_dir = os.getcwd()
    chem_dir_name = os.path.basename(current_dir)
    output_dir = os.path.join(current_dir, '0_cif_final')
    os.makedirs(output_dir, exist_ok=True)

    csv_files = glob.glob(os.path.join(current_dir, '*', 'energy_results.csv'))
    all_data = []

    print(f"Found {len(csv_files)} CSV files:")
    for csv_file in csv_files:
        print(f"  - {csv_file}")

    with open(os.path.join(current_dir, 'energy_final.txt'), 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(['Chemical_Formula', 'CIF_Base_Name', 'Total_Energy_eV', 
                        'Energy_per_Atom_eV', 'Final_Pressure_GPa', 
                        'Enthalpy_per_Atom_eV', 'Corrected_Enthalpy_per_Atom_eV',
                        'Relaxed_CIF_Path', 'SG_ori'])

        for csv_file in csv_files:
            space_group = os.path.basename(os.path.dirname(csv_file))
            print(f"Processing space group: {space_group}")

            try:
                with open(csv_file, 'r') as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    print(f"CSV header: {header}")

                    if len(header) < 7:
                        print(f"Warning: CSV does not appear to be from HP mode (expected 7 columns, got {len(header)})")
                        continue

                    for row in reader:
                        if len(row) < 7:
                            print(f"Skipping incomplete row: {row}")
                            continue

                        base_name = row[0].strip()
                        total_energy_str = row[1].strip()
                        energy_per_atom_str = row[2].strip()
                        final_pressure_str = row[3].strip()
                        enthalpy_str = row[4].strip()
                        corrected_enthalpy_str = row[5].strip()
                        cif_path = row[6].strip()

                        try:
                            total_energy = float(total_energy_str)
                            energy_per_atom = float(energy_per_atom_str)
                            final_pressure = float(final_pressure_str)
                            enthalpy_per_atom = float(enthalpy_str)
                            corrected_enthalpy = float(corrected_enthalpy_str)

                            if not os.path.exists(cif_path):
                                print(f"  Skipping {base_name}: CIF file not found")
                                continue

                            pressure_diff = abs(final_pressure - TARGET_PRESSURE)
                            if pressure_diff > PRESSURE_TOLERANCE:
                                print(f"  Skipping {base_name}: pressure {final_pressure:.1f} GPa outside tolerance")
                                continue

                            chemical_formula = "Unknown"
                            try:
                                structure = Structure.from_file(cif_path)
                                chemical_formula = structure.composition.formula.replace(" ", "")
                            except Exception as e:
                                print(f"Error reading CIF file {cif_path}: {e}")

                            writer.writerow([
                                chemical_formula,
                                base_name,
                                total_energy,
                                energy_per_atom,
                                final_pressure,
                                enthalpy_per_atom,
                                corrected_enthalpy,
                                cif_path,
                                space_group
                            ])

                            all_data.append({
                                'chemical_formula': chemical_formula,
                                'space_group': space_group,
                                'base_name': base_name,
                                'total_energy': total_energy,
                                'energy_per_atom': energy_per_atom,
                                'final_pressure': final_pressure,
                                'enthalpy_per_atom': enthalpy_per_atom,
                                'corrected_enthalpy': corrected_enthalpy,
                                'cif_path': cif_path
                            })

                        except ValueError as e:
                            print(f"Value conversion error: {e}, row data: {row}")
                            continue

            except Exception as e:
                print(f"Error processing file {csv_file}: {e}")
                continue

    if not all_data:
        print("No valid data found within pressure tolerance.")
        return

    all_data.sort(key=lambda x: x['corrected_enthalpy'])

    print(f"\nTotal entries within pressure tolerance: {len(all_data)}")
    print("First 10 enthalpies:")
    for i, d in enumerate(all_data[:10]):
        print(f"{i+1}. H = {d['corrected_enthalpy']:.6f} eV/atom, P = {d['final_pressure']:.1f} GPa")

    selected_data = []
    last_enthalpy = None

    for entry in all_data:
        if len(selected_data) >= MAX_N:
            break
        if last_enthalpy is None:
            selected_data.append(entry)
            last_enthalpy = entry['corrected_enthalpy']
        else:
            if entry['corrected_enthalpy'] - last_enthalpy >= ENTHALPY_GAP:
                selected_data.append(entry)
                last_enthalpy = entry['corrected_enthalpy']

    print(f"\nSelected {len(selected_data)} structures with enthalpy gap >= {ENTHALPY_GAP} eV/atom:")

    result_path = os.path.join(current_dir, '0_final_results.txt')
    with open(result_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Chemical_Formula', 'CIF_Base_Name', 'Total_Energy_eV',
                        'Energy_per_Atom_eV', 'Final_Pressure_GPa', 
                        'Enthalpy_per_Atom_eV', 'Corrected_Enthalpy_per_Atom_eV',
                        'Relaxed_CIF_Path', 'SG_ori'])
        for data in selected_data:
            writer.writerow([
                data['chemical_formula'],
                data['base_name'],
                data['total_energy'],
                data['energy_per_atom'],
                data['final_pressure'],
                data['enthalpy_per_atom'],
                data['corrected_enthalpy'],
                data['cif_path'],
                data['space_group']
            ])

    for idx, data in enumerate(selected_data):
        src = data['cif_path']
        dst = os.path.join(
            output_dir,
            f"{chem_dir_name}_{data['chemical_formula']}_{data['space_group']}_{data['base_name']}_hp_{idx+1}.cif"
        )
        if os.path.exists(src):
            shutil.copy(src, dst)
            print(f"Copied: {dst}")
        else:
            print(f"Warning: CIF not found: {src}")

    print(f"\nFinal selected structures (Target P = {TARGET_PRESSURE} GPa):")
    for i, d in enumerate(selected_data):
        if i == 0:
            diff = 0.0
        else:
            diff = d['corrected_enthalpy'] - selected_data[i-1]['corrected_enthalpy']
        print(f"{i+1}. H = {d['corrected_enthalpy']:.6f} eV/atom (D = {diff:.6f}) | "
              f"P = {d['final_pressure']:.1f} GPa | {d['chemical_formula']} | SG: {d['space_group']}")


if __name__ == "__main__":
    main()
