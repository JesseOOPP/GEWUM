import os
import shutil
from pathlib import Path

from pymatgen.io.cif import CifParser
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.analysis.structure_matcher import StructureMatcher


def get_standard_structure(structure):
    try:
        sga = SpacegroupAnalyzer(structure, symprec=0.01)
        return sga.get_primitive_standard_structure()
    except Exception as e:
        print(f"  Warning: Standardization failed, using primitive cell. Error: {e}")
        return structure.get_primitive_structure()


def get_unique_filename(base_name, used_names):
    stem = base_name.rsplit(".", 1)[0]
    suffix = ".cif"
    counter = 1
    new_name = base_name
    while new_name in used_names:
        new_name = f"{stem}_{counter}{suffix}"
        counter += 1
    used_names.add(new_name)
    return new_name


def collect_cif_files(root="."):
    cif_files = []
    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            if name.lower().endswith(".cif"):
                cif_files.append(os.path.join(dirpath, name))
    return cif_files


def main():
    output_dir = Path("0_s_cif")
    output_dir.mkdir(exist_ok=True)

    matcher = StructureMatcher(
        ltol=0.05,
        stol=0.05,
        angle_tol=0.5,
        primitive_cell=True,
    )

    unique_std_structures = []
    saved_filenames = set()

    cif_files = collect_cif_files(".")
    print(f"Found {len(cif_files)} CIF files. Starting deduplication...\n")

    for idx, cif_path in enumerate(cif_files, 1):
        rel_path = os.path.relpath(cif_path)
        print(f"[{idx}/{len(cif_files)}] Processing: {rel_path}")

        try:
            parser = CifParser(cif_path)
            structures = parser.get_structures(primitive=False)
            if not structures:
                print("  No structure found, skipping.")
                continue
            struct = structures[0]
            std_struct = get_standard_structure(struct)
        except Exception as e:
            print(f"  Error reading or standardizing: {e}")
            continue

        is_duplicate = False
        current_formula = std_struct.composition.reduced_formula
        for ref_std in unique_std_structures:
            if ref_std.composition.reduced_formula != current_formula:
                continue
            if matcher.fit(ref_std, std_struct):
                is_duplicate = True
                break

        if is_duplicate:
            print("  Duplicate structure, skipped.")
        else:
            unique_std_structures.append(std_struct)
            original_name = os.path.basename(cif_path)
            safe_name = get_unique_filename(original_name, saved_filenames)
            output_path = output_dir / safe_name
            shutil.copy2(cif_path, output_path)
            print(f"  Saved original CIF as: {output_path}")

    print("\nDeduplication complete!")
    print(f"   Total unique structures saved: {len(unique_std_structures)}")
    print(f"   Output directory: {output_dir.absolute()}")


if __name__ == "__main__":
    main()
